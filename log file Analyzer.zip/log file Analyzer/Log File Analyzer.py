file_name = 'sample_log.txt'

keyword = 'error' 

count = 0

try:
    with open(file_name,'r') as file:
        for line_number, line in enumerates(file, start=1):
            clean_line =line.strip().lower()

            if keyword.lower() in clean_line:
                print(f'line {line_number}: {line.strip()}') 
                count += 1
 if count > 0:
    print(f'\nThe "{keyword}" appears {count} times')
else:
    print (f'\nNo occurence of "{keyword}" found.')

except FileNotFoundError:

    print(f'the file {file_name} does not exist.')



